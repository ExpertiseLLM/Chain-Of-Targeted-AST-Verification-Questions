import platform


def os_is_mac():
	"""
	Checks if the os is macOS

:return: True is macOS
:rtype: bool
	"""
	from os import system, getuid, system
	if system() == 'Darwin':
		return True
	else:
		return False




def test_os_is_mac():
    """Check the correctness of os_is_mac
    """
    test_cases = dict()
    try:

        test_cases['test1']= os_is_mac() == (platform.system() == "Darwin")
        print(test_cases)
    except Exception as error:
        test_cases['test1'] = type(error).__name__
    print(test_cases)

if __name__ == "__main__":
    test_os_is_mac()


