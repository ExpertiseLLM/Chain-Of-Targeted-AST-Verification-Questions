def _replace_register(flow_params, register_number, register_value):
	"""
	Replace value from flows to given register number

'register_value' key in dictionary will be replaced by register number
given by'register_number'

:param flow_params: Dictionary containing defined flows
:param register_number: The number of register where value will be stored
:param register_value: Key to be replaced by register number
	"""
	for flow in flow_params.values():
		if flow.flow_type =='reg':
			flow.flow_type ='reg'
			flow.reg_number = register_number
			flow.reg_value = register_value


def test__replace_register():
    """
    Check the corretness of _replace_register
    """
    test_cases  = dict()
    try :
        test_cases['test1'] = _replace_register({'reg1': 1, 'reg2': 2, 'reg3': 3}, 1, 'reg1') == {'reg1': 1, 'reg2': 2, 'reg3': 3}
    except Exception as error:
        test_cases['test1'] = type(error).__name__
    try:
        test_cases['test2'] = _replace_register({'reg1': 1, 'reg2': 2, 'reg3': 3}, 2, 'reg2') == {'reg1': 1, 'reg2': 2, 'reg3': 3}
    except Exception as error:
        test_cases ['test2'] = type(error).__name__
    try:
        test_cases['test3'] = _replace_register({'reg1': 1, 'reg2': 2, 'reg3': 3}, 3, 'reg3') == {'reg1': 1, 'reg2': 2, 'reg3': 3}
    except Exception as error:
        test_cases['test3'] = type(error).__name__
    try:
        test_cases['test4'] = _replace_register({'reg1': 1, 'reg2': 2, 'reg3': 3}, 1, 'reg2') == {'reg1': 2, 'reg3': 3}
    except Exception as error:
        test_cases['test4'] = type(error).__name__
    try:
        test_cases['test5'] = _replace_register({'reg1': 1, 'reg2': 2, 'reg3': 3}, 2, 'reg3') == {'reg1': 1, 'reg2': 3}
    except Exception as error:
        test_cases['test5'] = type(error).__name__
    try:
        test_cases['test6'] = _replace_register({'reg1': 1, 'reg2': 2, 'reg3': 3}, 3, 'reg1') == {'reg2': 2, 'reg3': 1}
    except Exception as error:
        test_cases['test6'] = type(error).__name__
    print(test_cases)
if __name__ == "__main__":
    test__replace_register()


