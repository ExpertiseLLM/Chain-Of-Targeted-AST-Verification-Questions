def subclasses(cls):
    
    
    if not issubclass(cls, type):
        raise TypeError("Can only call subclasses() on classes")
    return cls.__subclasses__() + [g for s in cls.__subclasses__() for g in subclasses(s)]


def test_subclasses():
    """
    Check the corretness of subclasses
    """
    test_cases = dict()
    try:
        test_cases['test1']=subclasses(set) == set()
    except Exception as exeption :
        test_cases['test1'] = type(exeption).__name__
    print(test_cases)
if __name__ == "__main__":
    test_subclasses()


