import subprocess


def addignored(ignored):
	"""
	Use the git command to obtain the file names, turn it into a list, sort the list for only ignored files, return those files as a single string with each filename separated by a comma.
	"""
	try:
		output = subprocess.check_output(["git", "status", "-s", "--porcelain", "--porcelain-stdin"], universal_newlines=True)
	except subprocess.CalledProcessError as e:
		raise Exception(e.output)
	except IOError:
		raise Exception("Unable to read file status output.")

	ignored = [i.strip() for i in output.splitlines() if i.strip()]

	return ",".join(ignored)




def test_addignored():
    """Check the correctness of addignored
    """
    # print(addignored("."))
    test_cases = dict()
    try :
        test_cases['test1']= addignored(".") == " ocfl/__pycache__/"
    except Exception as error :
        test_cases['test1'] = type(error).__name__
    print(test_cases)
if __name__ == "__main__":
    test_addignored()


