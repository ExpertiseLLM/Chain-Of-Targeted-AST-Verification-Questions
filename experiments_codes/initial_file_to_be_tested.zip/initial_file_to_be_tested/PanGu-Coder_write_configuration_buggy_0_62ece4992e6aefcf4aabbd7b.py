import os


def write_configuration(config_filename, rendered_config, mode=0o600, overwrite=False):
    if not os.path.exists(config_filename):
        os.makedirs(os.path.dirname(config_filename))
    with open(config_filename, mode) as f:
        f.write(rendered_config)
    if overwrite:
        os.remove(config_filename)


def test_write_configuration():
    """Check the correctness of write_configuration
    """
    test_cases = dict()
    try:
        test_cases['test1'] = write_configuration('test.yaml', 'test', overwrite=True) == 'test'
    except Exception as error:
        test_cases['test1'] = type(error).__name__
    try:
        test_cases['test2'] = write_configuration('test.yaml', 'test', overwrite=False) == FileExistsError
    except Exception as error:
        test_cases['test2'] = type(error).__name__
    try:
        test_cases['test3'] = write_configuration('test.yaml', 'hhhhh', overwrite=True) == 'hhhhh'
    except Exception as error:
        test_cases['test3'] = type(error).__name__
    try:
        test_cases['test4'] = write_configuration('test.yaml', 'hhhhh', overwrite=False) == FileExistsError
    except Exception as error:
        test_cases['test4'] = type(error).__name__
    print(test_cases)

if __name__ == "__main__":
    test_write_configuration()


