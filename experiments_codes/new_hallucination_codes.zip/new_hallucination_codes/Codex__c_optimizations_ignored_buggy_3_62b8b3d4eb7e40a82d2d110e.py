def _c_optimizations_ignored():

	"""The opposite of `_c_optimizations_required`."""
	return not _c_optimizations_required()


